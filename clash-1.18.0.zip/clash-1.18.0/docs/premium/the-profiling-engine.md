---
sidebarTitle: "Feature: The Profiling Engine"
sidebarOrder: 8
---

# The Profiling Engine

https://github.com/Dreamacro/clash-tracing

```yaml
profile:
    tracing: true
```
